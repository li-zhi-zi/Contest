var a = "0";

function b(){
	a=a+100;
	var c = document.getElementById("result")
	c.innerHTML=a;
}


